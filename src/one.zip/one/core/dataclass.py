#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Advanced Data classes.
"""

from __future__ import annotations

import inspect
import os
import sys
import uuid

import cv2
import numpy as np
import torch
from joblib import delayed
from joblib import Parallel
from matplotlib import pyplot as plt
from munch import Munch
from torch import Tensor

from one.core.file import is_image_file
from one.core.file import is_json_file
from one.core.file import is_xml_file
from one.core.rich import console
from one.core.rich import print_table
from one.core.serialization import load_file
from one.core.types import assert_dict_contain_key
from one.core.types import assert_list_of
from one.core.types import assert_sequence_of_length
from one.core.types import assert_tensor_of_ndim
from one.core.types import BBoxFormat
from one.core.types import Dict
from one.core.types import Path
from one.core.types import VISION_BACKEND
from one.core.types import VisionBackend_


# MARK: - Functional

def majority_voting(labels: list[Dict]) -> Dict:
    """
    It counts the number of appearance of each label, and returns the label with
    the highest count.
    
    Args:
        labels (list[Dict]): List of object's label.
    
    Returns:
        A dictionary of the label that has the most votes.
    """
    # Count number of appearance of each label.
    unique_labels = Munch()
    label_voting  = Munch()
    for label in labels:
        k = label.get("id")
        v = label_voting.get(k)
        if v:
            label_voting[k] = v + 1
        else:
            unique_labels[k] = label
            label_voting[k]  = 1
    
    # Get k (label's id) with max v
    max_id = max(label_voting, key=label_voting.get)
    return unique_labels[max_id]


# MARK: - Modules

class BBox:
    """
    Bounding box object with (b1, b2, b3, b4, confidence) format.
    
    References:
        https://www.tensorflow.org/datasets/api_docs/python/tfds/features/BBox
    """
    
    # MARK: Magic Functions
    
    def __init__(
        self,
        b1        : float,
        b2        : float,
        b3        : float,
        b4        : float,
        confidence: float            = 1.0,
        id        : int | str        = uuid.uuid4().int,
        image_id  : int | str | None = None,
        class_id  : int | str | None = None,
        format    : BBoxFormat       = BBoxFormat.CXCYWH_NORM,
    ):
        self.id         = id
        self.image_id   = image_id
        self.class_id   = class_id
        self.b1         = b1
        self.b2         = b2
        self.b3         = b3
        self.b4         = b4
        self.confidence = confidence
        self.format     = format
    
    # MARK: Property
    
    @property
    def is_normalized(self) -> bool:
        """
        It checks if the values of the four variables are less than or equal
        to 1.0.
        
        Returns:
          A boolean value.
        """
        return all(i <= 1.0 for i in [self.b1, self.b2, self.b3, self.b4])
    
    @property
    def label(self) -> Tensor:
        """
        It returns a tensor containing the image id, class id, bounding box
        coordinates, and confidence
        
        Returns:
            A tensor of the image_id, class_id, b1, b2, b3, b4, and confidence.
        """
        return torch.Tensor(
            [
                self.image_id,
                self.class_id,
                self.b1, self.b2, self.b3, self.b4,
                self.confidence
            ],
            dtype=torch.float32
        )


class ClassLabel:
    """
    ClassLabel is a list of all classes' dictionaries in the dataset.
    
    References:
        https://www.tensorflow.org/datasets/api_docs/python/tfds/features/ClassLabel

    Attributes:
        classes (list[dict]):
            List of all classes in the dataset.
    """

    # MARK: Magic Functions

    def __init__(self, classes: list[dict]):
        self._classes = classes

    # MARK: Configure

    @staticmethod
    def create_from_dict(d: dict) -> ClassLabel:
        """
        It takes a dictionary and returns a ClassLabel object.
        
        Args:
            d (dict): dict.
        
        Returns:
            A ClassLabel object.
        """
        assert_dict_contain_key(d, "classes")
        classes = d["classes"]
        classes = Munch.fromDict(classes)
        return ClassLabel(classes=classes)
        
    @staticmethod
    def create_from_file(path: Path) -> ClassLabel:
        """
        It creates a ClassLabel object from a `json` file.
        
        Args:
            path (Path): The path to the `json` file.
        
        Returns:
            A ClassLabel object.
        """
        if not is_json_file(path=path):
            raise TypeError(f"`path` must be a `json` file. But got: {path}.")
        return ClassLabel.create_from_dict(d=load_file(path=path))
        
    # MARK: Property

    @property
    def classes(self) -> list:
        return self._classes

    def color_legend(self, height: int | None = None) -> Tensor:
        """
        It creates a legend of the classes in the dataset.
        
        Args:
            height (int | None): The height of the legend. If None, the legend
                will be 25px high per class.
        
        Returns:
            A tensor of the legend.
        """
        from one.vision.acquisition import to_tensor
        
        num_classes = len(self.classes)
        row_height  = 25 if (height is None) else int(height / num_classes)
        legend      = np.zeros(((num_classes * row_height) + 25, 300, 3), dtype=np.uint8)

        # NOTE: Loop over the class names + colors
        for i, label in enumerate(self.classes):
            color = label.color  # Draw the class name + color on the legend
            color = color[::-1]  # Convert to BGR format since OpenCV operates on BGR format.
            cv2.putText(
                img       = legend,
                text      = label.name,
                org       = (5, (i * row_height) + 17),
                fontFace  = cv2.FONT_HERSHEY_SIMPLEX,
                fontScale = 0.5,
                color     = (0, 0, 255),
                thickness = 2
            )
            cv2.rectangle(
                img       = legend,
                pt1       = (150, (i * 25)),
                pt2       = (300, (i * row_height) + 25),
                color     = color,
                thickness = -1
            )
        return to_tensor(image=legend)
        
    def colors(
        self,
        key                 : str  = "id",
        exclude_negative_key: bool = True,
        exclude_max_key     : bool = True
    ) -> list:
        """
        Returns a list of colors for each class in the dataset.
        
        Args:
            key (str): The key to search for. Defaults to id.
            exclude_negative_key (bool): If True, the negative value of the key
                will be excluded. Defaults to True.
            exclude_max_key (bool): If True, the maximum value of the key will
                be excluded. Defaults to True.
        
        Returns:
            A list of colors.
        """
        labels_colors = []
        for label in self.classes:
            if hasattr(label, key) and hasattr(label, "color"):
                if (exclude_negative_key and label[key] <  0  ) or \
                   (exclude_max_key      and label[key] >= 255):
                    continue
                labels_colors.append(label.color)
        return labels_colors

    @property
    def id2label(self) -> dict[int, dict]:
        """
        
        Returns:
            A dictionary with the label id as the key and the label as the
            value.
        """
        return {label["id"]: label for label in self.classes}

    def ids(
        self,
        key                 : str = "id",
        exclude_negative_key: bool = True,
        exclude_max_key     : bool = True
    ) -> list:
        """
        Returns a list of all the ids of the classes in the class list.
        
        Args:
            key (str): The key to search for. Defaults to id.
            exclude_negative_key (bool): If True, the negative value of the key
                will be excluded. Defaults to True.
            exclude_max_key (bool): If True, the maximum value of the key will
                be excluded. Defaults to True.
        
        Returns:
            A list of ids.
        """
        ids = []
        for c in self.classes:
            if hasattr(c, key):
                if (exclude_negative_key and c[key] <  0  ) or \
                   (exclude_max_key      and c[key] >= 255):
                    continue
                ids.append(c[key])
        return ids

    @property
    def list(self) -> list:
        return self.classes

    @property
    def name2label(self) -> dict[str, dict]:
        """
        
        Returns:
            A dictionary with the label name as the key and the label as the
            value.
        """
        return {c["name"]: c for c in self.classes}

    def names(
        self,
        exclude_negative_key: bool = True,
        exclude_max_key     : bool = True
    ) -> list:
        """
        It returns a list of names of the classes in the dataset.
        
        Args:
            exclude_negative_key (bool): If True, the negative value of the key
                will be excluded. Defaults to True.
            exclude_max_key (bool): If True, the maximum value of the key will
                be excluded. Defaults to True.
        
        Returns:
            A list of names of the classes.
        """
        names = []
        for c in self.classes:
            if hasattr(c, "id"):
                if (exclude_negative_key and c["id"] <  0  ) or \
                   (exclude_max_key      and c["id"] >= 255):
                    continue
                names.append(c["name"])
            else:
                names.append("")
        return names
    
    def num_classes(
        self,
        key                 : str  = "id",
        exclude_negative_key: bool = True,
        exclude_max_key     : bool = True
    ) -> int:
        """
        Count the number of classes in the dataset, excluding the negative and
        max classes if specified.
        
        Args:
            key (str): The key to search for. Defaults to id.
            exclude_negative_key (bool): If True, the negative value of the key
                will be excluded. Defaults to True.
            exclude_max_key (bool): If True, the maximum value of the key will
                be excluded. Defaults to True.
        
        Returns:
            The number of classes in the dataset.
        """
        count = 0
        for c in self.classes:
            if hasattr(c, key):
                if (exclude_negative_key and c[key] <  0  ) or \
                   (exclude_max_key      and c[key] >= 255):
                    continue
                count += 1
        return count

    # MARK: Custom Accessors

    def get_class(
        self,
        key  : str              = "id",
        value: int | str | None = None
    ) -> dict | None:
        """
        Returns the class with the given key and value, or None if no such
        class exists.
        
        Args:
            key (str): The key to search for. Defaults to id.
            value (int | str | None): The value of the key to search for.
                Defaults to None.
        
        Returns:
            A dictionary of the class that matches the key and value.
        """
        for c in self.classes:
            if hasattr(c, key) and (value == c[key]):
                return c
        return None
    
    def get_class_by_name(self, name: str) -> dict | None:
        """
        Returns the class with the given class name, or None if no such class
        exists.
        
        Args:
            name (str): The name of the class you want to get.
        
        Returns:
            A dictionary of the class with the given name.
        """
        return self.get_class(key="name", value=name)
    
    def get_id(
        self,
        key  : str              = "id",
        value: int | str | None = None
    ) -> int | None:
        """
        Returns the id of the class label that matches the given key and value.
        
        Args:
           key (str): The key to search for. Defaults to id.
            value (int | str | None): The value of the key to search for.
                Defaults to None.
        
        Returns:
            The id of the class.
        """
        class_label: dict = self.get_class(key=key, value=value)
        return class_label["id"] if class_label is not None else None
    
    def get_id_by_name(self, name: str) -> int | None:
        """
        Given a class name, return the class id.
        
        Args:
            name (str): The name of the class you want to get the ID of.
        
        Returns:
            The id of the class.
        """
        class_label = self.get_class_by_name(name=name)
        return class_label["id"] if class_label is not None else None
    
    def get_name(
        self,
        key  : str              = "id",
        value: int | str | None = None
    ) -> str | None:
        """
        Get the name of a class given a key and value.
        
        Args:
            key (str): The key to search for. Defaults to id.
            value (int | str | None): The value of the key to search for.
                Defaults to None.
        
        Returns:
            The name of the class.
        """
        c = self.get_class(key=key, value=value)
        return c["name"] if c is not None else None
       
    # MARK: Visualize

    def show_color_legend(self, height: int | None = None):
        """Show a pretty color lookup legend using OpenCV drawing functions.

        Args:
            height (int | None): Height of the color legend image.
                Defaults to None.
        """
        color_legend = self.color_legend(height=height)
        plt.imshow(color_legend.permute(1, 2, 0))
        plt.title("Color Legend")
        plt.show()
        
    # MARK: Print
    
    def print(self):
        """
        Print all classes using `rich` package.
        """
        if not (self.classes and len(self.classes) > 0):
            console.log("[yellow]No class is available.")
            return
        
        console.log("[red]Classlabel:")
        print_table(self.classes)


class Image:
    """
    Image object.
    
    References:
        https://www.tensorflow.org/datasets/api_docs/python/tfds/features/Image
    
    Args:
        id (int | str):
            The id of the image. This can be an integer or a string.
            This attribute is useful for batch processing where you want to
            keep the objects in the correct frame sequence.
        name (str):
            The name of the image. Defaults to None.
        path (Path | None):
            The path to the image file. Defaults to None.
        image (Tensor[*, C, H, W] | None):
            The image to be loaded. Defaults to None.
        load_on_create (bool):
            If True, the image will be loaded into memory when the object is
            created. Defaults to False.
        keep_in_memory (bool):
            If True, the image will be loaded into memory and kept there.
            Defaults to False.
        backend (VisionBackend, str):
            The backend to use for image processing. Defaults to VISION_BACKEND.
    """
    
    # MARK: Magic Functions
    
    def __init__(
        self,
        id            : int | str      = uuid.uuid4().int,
        name          : str | None     = None,
        path          : Path | None    = None,
        image         : Tensor | None  = None,
        load_on_create: bool           = False,
        keep_in_memory: bool           = False,
        backend       : VisionBackend_ = VISION_BACKEND,
    ):
        from one.vision.acquisition import get_image_shape
        
        self.id             = id
        self.image          = None
        self.keep_in_memory = keep_in_memory
        self.backend        = backend
        
        if path is not None:
            if is_image_file(path=path):
                raise FileNotFoundError(f"`path` must be valid. But got: {path}.")
        self.path = path
        
        if name is None:
            name = str(Path(path).name) if is_image_file(path=path) else f"{id}"
        self.name = name
        
        if load_on_create and image is None:
            image = self.load()

        self.shape = get_image_shape(image=image) if image is not None else None

        if self.keep_in_memory:
            self.image = image
    
    # MARK: Configure

    def load(
        self, path: Path | None = None, keep_in_memory: bool = False,
    ) -> Tensor:
        """Load image into memory.
        
        Args:
            path (Path | None):
                The path to the image file. Defaults to None.
            keep_in_memory (bool):
                If True, the image will be loaded into memory and kept there.
                Defaults to False.
            
        Returns:
            Return image Tensor of shape [1, C, H, W] to caller.
        """
        from one.vision.acquisition import read_image
        from one.vision.acquisition import get_image_shape
    
        self.keep_in_memory = keep_in_memory
        
        if is_image_file(path=path):
            self.path = path
        if not is_image_file(path=self.path):
            raise FileNotFoundError(f"`path` must be valid. But got: {self.path}.")
        
        image      = read_image(path=path, backend=self.backend)
        self.shape = get_image_shape(image=image) if (image is not None) else self.shape
        
        if self.keep_in_memory:
            self.image = image
        
        return image
    
    # MARK: Property
    
    @property
    def meta(self) -> dict:
        """
        It returns a dictionary of metadata about the object.
        
        Returns:
            A dictionary with the id, name, path, and shape of the image.
        """
        return {
            "id"   : self.id,
            "name" : self.name,
            "path" : self.path,
            "shape": self.shape,
        }


class KITTILabel:
    """
    
    """
    pass


class VOCBBox(BBox):
    """
    VOC bounding box object.
    
    References:
        https://www.tensorflow.org/datasets/api_docs/python/tfds/features/BBox
    
    Args:
        name (int | str): This is the name of the object that we are trying to
            identify (i.e., class_id).
        truncated (int): Indicates that the bounding box specified for the
            object does not correspond to the full extent of the object.
            For example, if an object is visible partially in the image then
            we set truncated to 1. If the object is fully visible then set
            truncated to 0.
        difficult (int): An object is marked as difficult when the object is
            considered difficult to recognize. If the object is difficult to
            recognize then we set difficult to 1 else set it to 0.
        bndbox (Tensor | list | tuple): Axis-aligned rectangle specifying the
            extent of the object visible in the image.
        pose (str): Specify the skewness or orientation of the image.
            Defaults to Unspecified, which means that the image is not skewed.
    """
    
    # MARK: Magic Functions
    
    def __init__(
        self,
        name     : str,
        truncated: int,
        difficult: int,
        bndbox   : Tensor | list | tuple,
        pose     : str = "Unspecified",
        *args, **kwargs
    ):
        if isinstance(bndbox, Tensor):
            assert_tensor_of_ndim(bndbox, 1)
            bndbox = bndbox.tolist()
        if isinstance(bndbox, (list, tuple)):
            assert_sequence_of_length(bndbox, 4)
        super().__init__(
            b1 = bndbox[0],
            b2 = bndbox[1],
            b3 = bndbox[2],
            b4 = bndbox[3],
            *args, **kwargs
        )
        self.name      = name
        self.pose      = pose
        self.truncated = truncated
        self.difficult = difficult
    
    # MARK: Configure
    
    def convert_name_to_id(self, class_labels: ClassLabel):
        """
        If the class name is a number, then it is the class id.
        Otherwise, the class id is searched from the ClassLabel object.
        
        Args:
            class_labels (ClassLabel): The ClassLabel containing all classes
                in the dataset.
        """
        self.class_id = int(self.name) \
            if self.name.isnumeric() \
            else class_labels.get_id(key="name", value=self.name)


class VOCLabel:
    """
    VOC label.
    
    Args:
        folder (str): Folder that contains the images.
        filename (str): Name of the physical file that exists in the folder.
        path (str): The absolute path where the image file is present.
        source (dict): Specifies the original location of the file in a
            database. Since we do not use a database, it is set to `Unknown`
            by default.
        size (dict): Specify the width, height, depth of an image. If the image
            is black and white then the depth will be 1. For color images,
            depth will be 3.
        segmented (int): Signify if the images contain annotations that are
            non-linear (irregular) in shape - commonly referred to as polygons.
            Defaults to 0 (linear shape).
        object (dict | list | None): Contains the object details. If you have
            multiple annotations then the object tag with its contents is
            repeated. The components of the object tags are:
            - name (int, str): This is the name of the object that we are
                trying to identify (i.e., class_id).
            - pose (str): Specify the skewness or orientation of the image.
                Defaults to `Unspecified`, which means that the image is not
                skewed.
            - truncated (int): Indicates that the bounding box specified for
                the object does not correspond to the full extent of the object.
                For example, if an object is visible partially in the image
                then we set truncated to 1. If the object is fully visible then
                set truncated to 0.
            - difficult (int): An object is marked as difficult when the object
                is considered difficult to recognize. If the object is
                difficult to recognize then we set difficult to 1 else set it
                to 0.
            - bndbox (dict): Axis-aligned rectangle specifying the extent of
                the object visible in the image.
        class_labels (ClassLabel | None): ClassLabel object. Defaults to None.
    """
    
    # MARK: Magic Functions
    
    def __init__(
        self,
        folder      : str,
        filename    : str,
        path        : str,
        source      : dict,
        size        : dict,
        segmented   : int,
        object      : dict | list | None,
        class_labels: ClassLabel | None = None,
        *args, **kwargs
    ):
        from one.vision.shape import box_xyxy_to_cxcywh_norm
        
        self.folder    = folder
        self.filename  = filename
        self.path      = path
        self.source    = source
        self.size      = size
        self.width     = int(self.size.get("width",  0))
        self.height    = int(self.size.get("height", 0))
        self.depth     = int(self.size.get("depth",  0))
        self.segmented = segmented

        if object is None:
            object = []
        else:
            object = [object] if not isinstance(object, dict) else object
        assert_list_of(object, dict)
        
        for i, o in enumerate(object):
            bndbox   = o.get("bndbox")
            box_xyxy = torch.FloatTensor([
                int(bndbox["xmin"]), int(bndbox["ymin"]),
                int(bndbox["ymin"]), int(bndbox["ymax"])
            ])
            o["bndbox"] = box_xyxy_to_cxcywh_norm(box_xyxy, self.height, self.width)
            o["format"] = BBoxFormat.CXCYWH_NORM
        self.bboxes = [VOCBBox(*b) for b in object]
        
        if isinstance(class_labels, ClassLabel):
            self.convert_names_to_ids(class_labels=class_labels)
        
    # MARK: Configure

    @staticmethod
    def create_from_dict(d: dict, *args, **kwargs) -> VOCLabel:
        """
        Create a VOCLabel object from a dictionary.
        
        Args:
            d (dict):
                Dictionary containing VOC data.
        
        Returns:
            A VOCLabel object.
        """
        assert_dict_contain_key(d, "annotation")
        d = d["annotation"]
        return VOCLabel(
            folder    = d.get("folder"   , ""),
            filename  = d.get("filename" , ""),
            path      = d.get("path"     , ""),
            source    = d.get("source"   , {"database": "Unknown"}),
            size      = d.get("size"     , {"width": 0, "height": 0, "depth": 3}),
            segmented = d.get("segmented", 0),
            object    = d.get("object"   , []),
            *args, **kwargs
        )
        
    @staticmethod
    def create_from_file(path: Path, *args, **kwargs) -> VOCLabel:
        """
        Load VOC label from file.
        
        Args:
            path (Path): Annotation file.
                
        Returns:
            A VOCLabel object.
        """
        if not is_xml_file(path=path):
            raise FileNotFoundError(f"`path` must be a `xml` file. But got: {path}.")
        return VOCLabel.create_from_dict(d=load_file(path=path), *args, **kwargs)
   
    def convert_names_to_ids(
        self, class_labels: ClassLabel, parallel: bool = False
    ):
        """
        Convert `name` property in each `object` to class id.
        
        Args:
            class_labels (ClassLabel): The ClassLabel containing all classes
                in the dataset.
            parallel (bool): If True, run parallely. Defaults to False.
        """
        if parallel:
            def run(i):
                self.bboxes[i].convert_name_to_id(class_labels)
            
            Parallel(n_jobs=os.cpu_count(), require="sharedmem")(
                delayed(run)(i) for i in range(len(self.objects))
            )
        else:
            for o in self.bboxes:
                o.convert_name_to_id(class_labels=class_labels)


# MARK: - Main

__all__ = [
    name for name, value in inspect.getmembers(
        sys.modules[__name__],
        predicate=lambda f: inspect.isfunction(f) and f.__module__ == __name__
    )
]
