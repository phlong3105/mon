#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
"""

from __future__ import annotations

from .scaled_yolov4 import *
from .yolov5_v4 import *
from .yolov5_v6_1 import *
from .yolov7 import *
