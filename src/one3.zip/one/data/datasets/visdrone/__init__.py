#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""VisDrone datasets and datamodules.
"""

from __future__ import annotations

from .visdrone19det import *
