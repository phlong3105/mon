#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""This package defines models' training/testing/predicting configurations."""

from __future__ import annotations

import mon.createml.config.default
