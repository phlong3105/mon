//
//  oneswift.h
//  oneswift
//
//  Created by Long H. Pham on 2022/05/20.
//

#import <Foundation/Foundation.h>

//! Project version number for oneswift.
FOUNDATION_EXPORT double oneswiftVersionNumber;

//! Project version string for oneswift.
FOUNDATION_EXPORT const unsigned char oneswiftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <oneswift/PublicHeader.h>


