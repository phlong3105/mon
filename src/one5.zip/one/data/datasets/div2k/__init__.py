#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
"""


from __future__ import annotations

from .div2k import *
from .div2kbicubic import *
from .div2kbicubicx2 import *
from .div2kbicubicx3 import *
from .div2kbicubicx4 import *
from .div2kdifficult import *
from .div2kmild import *
from .div2kunknown import *
from .div2kunknownx2 import *
from .div2kunknownx3 import *
from .div2kunknownx4 import *
from .div2kx8 import *
