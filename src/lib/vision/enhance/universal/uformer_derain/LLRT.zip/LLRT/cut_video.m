clear
addpath(genpath('Utilize/'));
nSig = 1;
dir_path = '\InternetData\dataMat';
file_list = dir(dir_path);
for i = 3:length(file_list)
load(['\InternetData\dataMat\' file_list(i).name]);

Par   = ParSet(nSig); 
Par.patnum = 100;
Par.Iter = 6;
Par.patsize = 6;
Par.step = 5;

tic
[EEE]= SSLRR_DeNoising( N_Img, N_Img, Par);
toc
[~, file_name_no_ext, ~] = fileparts(file_list(i).name);
mkdir(['\results\1\' file_name_no_ext]);
for kk = 1:size(N_Img,3)
    EImg2 = zeros(size(N_Img,1),size(N_Img,2),3);
    EImg2 = EImg(:,:,:,kk);
    EImg2(:,:,1) = EEE(:,:,kk);
    EImg2 = uint8(EImg2);
    EE_Img = ycbcr2rgb(EImg2);    
    imwrite(EE_Img,['\results\1\' file_name_no_ext '\' file_name_no_ext '_nsig' num2str(nSig) '_patnum' num2str(Par.patnum) '_average_order_iter' num2str(Par.Iter) '_' num2str(kk) '.png'])
end
end
