%% ����mat���ݸ�������
clear
dir_path = 'F:\\projects\\ȥ�����\\InternetData\\data\\';
file_list = dir(dir_path);

for i = 3:length(file_list)
    VidObj = VideoReader(strcat('.\InternetData\data\',file_list(i).name));
    nFrames = 300; 
    vidHeight = VidObj.Height; 
    vidWidth = VidObj.Width; 
    
    I = read(VidObj, 60);
    EImg = zeros([size(I) floor(nFrames/30)]);
    
    count = 0;
    N_Img = zeros(size(I,1),size(I,2),floor(nFrames/30));
    for k = 1:floor(nFrames/30)
        count = count+1;
        sumI = zeros(size(I,1),size(I,2));
        for q = 1:30
            I = read(VidObj, 30*(k-1)+q);
            ycbcrI = double(rgb2ycbcr(I));
            sumI = sumI+double(ycbcrI(:,:,1));
            EImg(:,:,2:3,k) = EImg(:,:,2:3,k) + ycbcrI(:,:,2:3);
        end
        aveI = sumI/30;
        N_Img(:,:,count) = aveI;
        EImg(:,:,2:3,k) = EImg(:,:,2:3,k) / 30;
    end
    [~, file_name_no_ext, ~] = fileparts(file_list(i).name);
    save([strcat('.\InternetData\dataMat\',file_name_no_ext,'.mat')],'EImg','N_Img');
end
