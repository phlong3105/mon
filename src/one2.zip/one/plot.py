# !/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Plotting functions.
"""

from __future__ import annotations

import inspect
import math
import sys
from typing import Any

import cv2
import matplotlib
import numpy as np
import torch
import torchvision
from matplotlib import pyplot as plt
from multipledispatch import dispatch
from torch import Tensor

from one.core import Arrays
from one.core import ClassLabel
from one.core import Colors
from one.core import Strs
from one.core import TensorOrArray
from one.core import to_4d_array_list

plt.ion()
plt.switch_backend("qt5agg")


# H1: - Drawing ----------------------------------------------------------------

def _draw_box(
    image    : np.ndarray,
    labels   : np.ndarray,
    colors   : Colors | None = None,
    thickness: int           = 5
) -> np.ndarray:
    """
    Draw bounding box(es) on image. If given the `colors`, use the color index
    corresponding with the `class_id` of the labels.

    Args:
        image (np.ndarray):
            Can be a 4D batch of numpy array or a single image.
        labels (np.ndarray):
            Bounding box labels where the bounding boxes coordinates are
            located at: labels[:, 2:6]. Also, the bounding boxes are in [
            xyxy] format.
        colors (list, None):
            List of colors. Default: `None`.
        thickness (int):
            Thickness of the bounding box border.

    Returns:
        image (np.ndarray):
            Image with drawn bounding boxes.
    """
    # Draw bbox
    image = np.ascontiguousarray(image, dtype=np.uint8)
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    for i, l in enumerate(labels):
        class_id    = int(l[1])
        start_point = l[2:4].astype(np.int)
        end_point   = l[4:6].astype(np.int)
        color		= (255, 255, 255)
        if isinstance(colors, (tuple, list)) and len(colors) >= class_id:
            color = colors[class_id]
        image = cv2.rectangle(
            img=image, pt1=tuple(start_point), pt2=tuple(end_point),
            color=tuple(color), thickness=thickness
        )
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    return image


def _draw_pixel(image: Tensor, x: int, y: int, color: Tensor):
    """
    Draws a pixel into an image.

    Args:
        image (Tensor):
            Input image to where to draw the lines with shape [C, H, W].
        x (int):
            Fx coordinate of the pixel.
        y (int):
            Fy coordinate of the pixel.
        color (Tensor):
            Color of the pixel with [C] where `C` is the number of channels
            of the image.
    """
    image[:, y, x] = color


@dispatch(Tensor, Tensor, list, int)
def draw_box(
    image    : Tensor,
    labels   : Tensor,
    colors   : Colors | None = None,
    thickness: int           = 1
):
    """Draw bounding box(es) on image(s). If given the `colors`, use the color
    index corresponding with the `class_id` of the labels.

    Args:
        image (Tensor):
            Can be a 4D batch of Tensor or a single image.
        labels (Tensor):
            Bounding box labels where the bounding boxes coordinates are
            located at: labels[:, 2:6]. Also, the bounding boxes are in
            [xyxy] format.
        colors (list, None):
            List of colors. Default: `None`.
        thickness (int):
            Thickness of the bounding box border.
    """
    image_np  = image.numpy()
    labels_np = labels.numpy()
    return draw_box(image_np, labels_np, colors, thickness)


@dispatch(np.ndarray, np.ndarray, list, int)
def draw_box(
    image    : np.ndarray,
    labels   : np.ndarray,
    colors   : Colors | None = None,
    thickness: int           = 1
):
    """Draw bounding box(es) on image(s). If given the `colors`, use the color
    index corresponding with the `class_id` of the labels.

    Args:
        image (np.ndarray):
            Can be a 4D batch of numpy array or a single image.
        labels (np.ndarray):
            Bounding box labels where the bounding boxes coordinates are
            located at: labels[:, 2:6]. Also, the bounding boxes are in
            [xyxy] format.
        colors (list, None):
            List of colors. Default: `None`.
        thickness (int):
            Thickness of the bounding box border.
    """
    from one.vision.acquisition import to_channel_last
    from one.vision.transformation import denormalize_naive
    
    # Convert to channel-last
    image = to_channel_last(image)
    
    # Unnormalize image
    image = denormalize_naive(image)
    image = image.astype(np.uint8)
    
    if not 3 <= image.ndim <= 4:
        raise ValueError(f"Require 3 <= `image.ndim` <= 4. But got: {image.ndim}.")
    # If the images are of shape [CHW]
    if image.ndim == 3:
        return _draw_box(image, labels, colors, thickness)
    
    # If the images are of shape [BCHW]
    if image.ndim == 4:
        imgs = []
        for i, img in enumerate(image):
            l = labels[labels[:, 0] == i]
            imgs.append(_draw_box(img, l, colors, thickness))
        imgs = np.stack(imgs, axis=0).astype(np.unit8)
        return imgs
    

def draw_line(image: Tensor, p1: Tensor, p2: Tensor, color: Tensor) -> Tensor:
    """Draw a single line into an image.

    Args:
        image (Tensor):
            Input image to where to draw the lines with shape [C, H, W].
        p1 (Tensor):
            Start point [x y] of the line with shape (2).
        p2 (Tensor):
            End point [x y] of the line with shape (2).
        color (Tensor):
            Color of the line with shape [C] where `C` is the number of
            channels of the image.

    Return:
        image (Tensor):
            Image with containing the line.

    Examples:
    >>> image = torch.zeros(1, 8, 8)
    >>> draw_line(image, torch.tensor([6, 4]), torch.tensor([1, 4]), torch.tensor([255]))
    image([[[  0.,   0.,   0.,   0.,   0.,   0.,   0.,   0.],
             [  0.,   0.,   0.,   0.,   0.,   0.,   0.,   0.],
             [  0.,   0.,   0.,   0.,   0.,   0.,   0.,   0.],
             [  0.,   0.,   0.,   0.,   0.,   0.,   0.,   0.],
             [  0., 255., 255., 255., 255., 255., 255.,   0.],
             [  0.,   0.,   0.,   0.,   0.,   0.,   0.,   0.],
             [  0.,   0.,   0.,   0.,   0.,   0.,   0.,   0.],
             [  0.,   0.,   0.,   0.,   0.,   0.,   0.,   0.]]])
    """
    if not (len(p1) == 2) and (len(p2) == 2):
        raise ValueError(
            f"`p1` and `p2` must have length of 2. "
            f"But got: {len(p1)} or {len(p2)}."
        )
    if not image.ndim == 3:
        raise ValueError(f"Require `image.ndim` == 3. But got: {image.ndim}.")
    if color.size(0) == image.size(0):
        raise ValueError(
            f"`color` and `image` must have the same channels. "
            f"But got: {color.size(0)} != {image.size(0)}."
        )
    if ((p1[0] >= image.size(2)) or
        (p1[1] >= image.size(1) or
         (p1[0] < 0) or
         (p1[1] < 0))):
        raise ValueError("`p1` is out of bounds.")
    if ((p2[0] >= image.size(2)) or
        (p2[1] >= image.size(1) or
         (p2[0] < 0) or
         (p2[1] < 0))):
        raise ValueError("`p2` is out of bounds.")
    
    # Make move arguments to same device and dtype as the input image
    p1, p2, color = p1.to(image), p2.to(image), color.to(image)
    
    # Assign points
    x1, y1 = p1
    x2, y2 = p2
    
    # Calculate coefficients A,B,C of line from equation Ax + By + C = 0
    A = y2 - y1
    B = x1 - x2
    C = x2 * y1 - x1 * y2
    
    # Make sure A is positive to utilize the function properly
    if A < 0:
        A = -A
        B = -B
        C = -C

    # Calculate the slope of the line
    # Check for division by zero
    if B != 0:
        m = -A / B

    # Make sure you start drawing in the right direction
    x1, x2 = min(x1, x2).long(), max(x1, x2).long()
    y1, y2 = min(y1, y2).long(), max(y1, y2).long()

    # Line equation that determines the distance away from the line
    def line_equation(x, y):
        return A * x + B * y + C

    # Vertical line
    if B == 0:
        image[:, y1:y2 + 1, x1] = color
    # Horizontal line
    elif A == 0:
        image[:, y1, x1:x2 + 1] = color
    # Slope between 0 and 1
    elif 0 < m < 1:
        for i in range(x1, x2 + 1):
            _draw_pixel(image, i, y1, color)
            if line_equation(i + 1, y1 + 0.5) > 0:
                y1 += 1
    # Slope >= 1
    elif m >= 1:
        for j in range(y1, y2 + 1):
            _draw_pixel(image, x1, j, color)
            if line_equation(x1 + 0.5, j + 1) < 0:
                x1 += 1
    # Slope < -1
    elif m <= -1:
        for j in range(y1, y2 + 1):
            _draw_pixel(image, x2, j, color)
            if line_equation(x2 - 0.5, j + 1) > 0:
                x2 -= 1
    # Slope between -1 and 0
    elif -1 < m < 0:
        for i in range(x1, x2 + 1):
            _draw_pixel(image, i, y2, color)
            if line_equation(i + 1, y2 - 0.5) > 0:
                y2 -= 1

    return image


def draw_rectangle(
    image    : Tensor,
    rectangle: Tensor,
    color    : Tensor | None = None,
    fill     : bool | None   = None,
) -> Tensor:
    """Draw N rectangles on a batch of image tensors.

    Args:
        image (Tensor):
            Tensor of shape [B, C, H, W].
        rectangle (Tensor):
            Represents number of rectangles to draw in [B, N, 4].
            N is the number of boxes to draw per batch index [x1, y1, x2, y2]
            4 is in (top_left.x, top_left.y, bot_right.x, bot_right.y).
        color (Tensor, None):
            A size 1, size 3, [B, N, 1], or [B, N, 3] image.
            If `C` is 3, and color is 1 channel it will be broadcasted.
            Default: `None`.
        fill (bool, None):
            A flag used to fill the boxes with color if `True`. Default: `None`.

    Returns:
        image (Tensor):
            This operation modifies image inplace but also returns the drawn
            image for convenience with same shape the of the input
            [B, C, H, W].

    Example:
        >>> img  = torch.rand(2, 3, 10, 12)
        >>> rect = torch.tensor([[[0, 0, 4, 4]], [[4, 4, 10, 10]]])
        >>> out  = draw_rectangle(img, rect)
    """
    batch, c, h, w = image.shape
    batch_rect, num_rectangle, num_points = rectangle.shape
    if not batch == batch_rect:
        raise ValueError(
            f"`image` and `rectangle` must have the same batch size. "
            f"But got: {batch} != {batch_rect}."
        )
    if num_points == 4:
        raise ValueError(f"Require `num_points` == 4. But got: {num_points}.")

    # Clone rectangle, in case it's been expanded assignment from clipping
    # causes problems
    rectangle = rectangle.long().clone()

    # Clip rectangle to hxw bounds
    rectangle[:, :, 1::2] = torch.clamp(rectangle[:, :, 1::2], 0, h - 1)
    rectangle[:, :, ::2]  = torch.clamp(rectangle[:, :, ::2], 0, w - 1)

    if color is None:
        color = torch.tensor([0.0] * c).expand(batch, num_rectangle, c)

    if fill is None:
        fill = False

    if len(color.shape) == 1:
        color = color.expand(batch, num_rectangle, c)

    b, n, color_channels = color.shape

    if color_channels == 1 and c == 3:
        color = color.expand(batch, num_rectangle, c)

    for b in range(batch):
        for n in range(num_rectangle):
            if fill:
                image[
                    b, :,
                    int(rectangle[b, n, 1]): int(rectangle[b, n, 3] + 1),
                    int(rectangle[b, n, 0]): int(rectangle[b, n, 2] + 1),
                ] = color[b, n, :, None, None]
            else:
                image[
                    b, :,
                    int(rectangle[b, n, 1]): int(rectangle[b, n, 3] + 1),
                    rectangle[b, n, 0]
                ] = color[b, n, :, None]
                image[
                    b, :,
                    int(rectangle[b, n, 1]): int(rectangle[b, n, 3] + 1),
                    rectangle[b, n, 2]
                ] = color[b, n, :, None]
                image[
                    b, :,
                    rectangle[b, n, 1],
                    int(rectangle[b, n, 0]): int(rectangle[b, n, 2] + 1)
                ] = color[b, n, :, None]
                image[
                    b, :,
                    rectangle[b, n, 3],
                    int(rectangle[b, n, 0]): int(rectangle[b, n, 2] + 1)
                ] = color[b, n, :, None]

    return image


# H1: - Positioning ------------------------------------------------------------

@dispatch(Tensor, int)
def make_image_grid(images: Tensor, nrow: int = 1) -> Tensor:
    """Concatenate multiple images into a single image.

    Args:
        images (Tensor):
            Images can be:
                - A 4D mini-batch image of shape [B, C, H, W].
                - A 3D RGB image of shape [C, H, W].
                - A 2D grayscale image of shape [H, W].
        nrow (int):
            Number of images in each row of the grid. Final grid size is
            `[B / nrow, nrow]`. Default: `1`.

    Returns:
        cat_image (Tensor):
            Concatenated image.
    """
    return torchvision.utils.make_grid(tensor=images, nrow=nrow)


@dispatch(np.ndarray, int)
def make_image_grid(images: np.ndarray, nrow: int = 1) -> np.ndarray:
    """Concatenate multiple images into a single image.

    Args:
        images (np.array):
            Images can be:
                - A 4D mini-batch image of shape [B, C, H, W].
                - A 3D RGB image of shape [C, H, W].
                - A 2D grayscale image of shape [H, W].
        nrow (int):
            Number of images in each row of the grid. Final grid size is
            `[B / nrow, nrow]`. Default: `1`.

    Returns:
        cat_image (np.ndarray):
            Concatenated image.
    """
    from one.vision.acquisition import is_channel_first
    from one.vision.acquisition import to_channel_last
    
    # Type checking
    if images.ndim == 3:
        return images
    
    # Conversion (just for sure)
    if is_channel_first(images):
        images = to_channel_last(images)
    
    b, c, h, w = images.shape
    ncols = nrow
    nrows = (b // nrow) if (b // nrow) > 0 else 1
    cat_image = np.zeros((c, int(h * nrows), w * ncols))
    for idx, im in enumerate(images):
        j = idx // ncols
        i = idx % ncols
        cat_image[:, j * h: j * h + h, i * w: i * w + w] = im
    return cat_image


@dispatch(list, int)
def make_image_grid(images: list, nrow: int = 1) -> TensorOrArray:
    """Concatenate multiple images into a single image.

    Args:
        images (list):
            A list of images of shape [C, H, W].
        nrow (int):
            Number of images in each row of the grid. Final grid size is
            `[B / nrow, nrow]`. Default: `1`.

    Returns:
        cat_image (Image):
            Concatenated image.
    """
    if isinstance(images, list) and all(torch.is_tensor(t) for t in images):
        return torchvision.utils.make_grid(tensor=images, nrow=nrow)
    else:
        raise TypeError(
            f"`image` must be a `list` of `Tensor`. But got: {type(images)}."
        )


@dispatch(dict, int)
def make_image_grid(images: dict, nrow: int = 1) -> TensorOrArray:
    """Concatenate multiple images into a single image.

    Args:
        images (dict):
            A dict of images of the same shape [C, H, W].
        nrow (int, None):
            Number of images in each row of the grid. Final grid size is
            `[B / nrow, nrow]`. Default: `1`.

    Returns:
        cat_image (Image):
            Concatenated image.
    """
    if (isinstance(images, dict)
        and all(torch.is_tensor(t) for k, t in images.items())):
        values = list(tuple(images.values()))
        return torchvision.utils.make_grid(values, nrow)
    else:
        raise TypeError(
            f"`image` must be a `dict` of `Tensor`. But got: {type(images)}."
        )


def move_figure(x: int, y: int):
    """Move figure's upper left corner to pixel (x, y)."""
    mngr    = plt.get_current_fig_manager()
    fig     = plt.gcf()
    backend = matplotlib.get_backend()
    
    if backend == "TkAgg":
        mngr.window.wm_geometry("+%d+%d" % (x, y))
    elif backend == "WXAgg":
        mngr.window.SetPosition((x, y))
    else:  # This works for QT and GTK. You can also use window.setGeometry
        mngr.window.move(x, y)


# H1: - Visualize --------------------------------------------------------------

def show_images(
    images     : Any,
    nrow       : int   = 8,
    denormalize: bool  = False,
    figure_num : int   = 0,
    wait_time  : float = 0.001
):
    """Visualize images for debugging purpose.

    Args:
        images (Any):
            Images to be shown.
        nrow (int):
            Number of images displayed in each row of the grid. Ffinal grid
            size is `[B / nrow, nrow]`.
        denormalize (bool):
            Should denormalize the images? Default: `False`.
        figure_num (int):
            matplotlib figure id.
        wait_time (float):
            Wait some time (in seconds) to display the figure then reset.
    """
    from one.vision.acquisition import to_image
    from one.vision.acquisition import to_pil_image
    
    # Make an image grid
    cat_image = make_image_grid(images, nrow)
    cat_image = to_image(cat_image, denormalize=denormalize)
    """
    cat_image = cat_image.numpy() if torch.is_tensor(cat_image) else cat_image
    cat_image = to_channel_last(cat_image)
    if denormalize:
        from onecore.vision import denormalize_naive
        cat_image = denormalize_naive(cat_image)
    """
    
    # Convert to PIL Image
    cat_image = to_pil_image(image=cat_image)
    
    # Clear old figure and visualize current one
    fig = plt.figure(num=figure_num)
    fig.clf()
    plt.imshow(cat_image, interpolation="bicubic")
    plt.pause(wait_time)


def imshow_plt(
    images    : Any,
    labels    : Strs | None = None,
    scale     : int         = 1,
    save_cfg  : dict | None = None,
    verbose	  : bool		= True,
    show_max_n: int		    = 8,
    wait_time : float       = 0.01,
    figure_num: int         = 0,
):
    """Visualize images as a grid using matplotlib.
    
    Args:
        images (Any):
            A sequence of images. Each element is of shape [B, C, H, W].
        labels (Sequence[str], None):
            Sequence of images' labels string. Default: `None`.
        scale (int):
            Scale the size of matplotlib figure. `1` means (default size x 1).
        save_cfg (dict, None):
            Save figure config. Default: `None`.
        verbose (bool):
            If `True`, verbose the debug image, else skip. Default: `True`.
        show_max_n (int):
            Show at max n images. Default: `8`.
        wait_time (float):
            Wait some time (in seconds) to display the figure then reset.
        figure_num (int):
            Matplotlib figure id. Default: `0`.
            
    Examples:
        >>> import cv2
        >>> import numpy as np
        >>> bgr     = cv2.imread("MLKit/tests/lenna.png")
        >>> rgb     = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        >>>
        >>> rgbs    = np.array([rgb, rgb, rgb])
        >>> bgrs    = np.array([bgr, bgr, bgr])
        >>>
        >>> outputs = [rgbs, bgrs]
        >>> labels  = ["RGB", "BGR"]
        >>> imshow_plt(images=outputs, labels=labels, figure_num=0, scale=1)
        >>>
        >>> outputs = { "RGB": rgbs, "BGR": bgrs }
        >>> imshow_plt(images=outputs, figure_num=1, scale=2)
    """
    from one.vision.transformation import denormalize_naive
    from one.vision.acquisition import to_channel_last
    
    if not verbose and save_cfg is None:
        return
    
    # Prepare images
    images_ = to_4d_array_list(images)  # List of 4D-array
    images_ = [to_channel_last(i)	for i in images_]
    images_ = [denormalize_naive(i) for i in images_]
    images_ = [i[: show_max_n]    	for i in images_]
    
    # Prepare labels
    if isinstance(images, dict):
        labels = images.keys() if labels is None else labels
    if labels is None:
        labels = ["" for _ in range(len(images))]
    if len(labels) != len(images):
        raise ValueError(f"`labels` and `images` must have the same length."
                         f" But got: {len(labels)} != {len(images)}.")
    
    # Create an image grid
    ncols           = len(images_)
    nrows, h, w, c  = images_[0].shape
    nrows          += 0 if nrows > 1 else 1
    
    fig, axes = plt.subplots(
        nrows   = nrows,
        ncols   = ncols,
        figsize = [ncols * scale, nrows * scale],
        num     = figure_num,
        clear   = True,
    )
    move_figure(x=0, y=0)
    [ax.set_title(l) for ax, l in zip(axes[0], labels)]
    for i, imgs in enumerate(images_):
        # axes[0, i].set_title(labels[i])
        for j, img in enumerate(imgs):
            axes[j, i].imshow(img, aspect="auto")
            axes[j, i].set_yticklabels([])
            axes[j, i].set_xticklabels([])
    plt.tight_layout()
    plt.subplots_adjust(wspace=0.0, hspace=0.0)
    plt.show()
    
    # Save figure
    if save_cfg:
        filepath = save_cfg.pop("filepath")
        plt.savefig(filepath, **save_cfg)
        
    # Show
    if verbose:
        plt.show()
        plt.pause(wait_time)
        

def imshow_cls_plt(
    images 	    : Any,
    preds	    : Arrays | None     = None,
    targets	    : Arrays | None     = None,
    labels	    : Strs | None       = None,
    class_labels: ClassLabel | None = None,
    top_k	    : int 				= 5,
    scale       : int               = 1,
    save_cfg    : dict | None       = None,
    verbose	    : bool				= True,
    show_max_n  : int				= 8,
    wait_time   : float             = 0.01,
    figure_num  : int               = 0,
):
    """Visualize classification results on images using matplotlib.
    
    Args:
        images (Any):
            A sequence of images. Each element is of shape [B, C, H, W].
        preds (Arrays, None):
            A sequence of predicted classes probabilities. Default: `None`.
        targets (Arrays, None):
            A sequence of ground-truths. Default: `None`.
        labels (Sequence[str], None):
            Sequence of images' labels string. Default: `None`.
        class_labels (ClassLabels, None):
            `ClassLabels` objects that contains all class labels in the
            datasets. Default: `None`.
        top_k (int):
            Show only the top k classes' probabilities. Default: `5`.
        scale (int):
            Scale the size of matplotlib figure. `1` means (default size x 1).
        save_cfg (dict, None):
            Save figure config.
        verbose (bool):
            If `True`, verbose the debug image, else skip. Default: `True`.
        show_max_n (int):
            Show at max n images. Default: `8`.
        wait_time (float):
            Wait some time (in seconds) to display the figure then reset.
        figure_num (int):
            Matplotlib figure id. Default: `0`.
    """
    from one.vision.acquisition import to_image
    from one.vision.acquisition import to_channel_last
    
    if not verbose and save_cfg is None:
        return
    
    # Prepare images
    images_ = to_image(images, denormalize=True)  # 4D-array
    images_ = to_channel_last(images_)
    images_ = images_[:show_max_n]
    
    # Prepare preds and targets
    pred_scores   = np.sort(preds, axis=1)[:show_max_n, -top_k:][:, ::]
    pred_labels   = preds.argsort(axis=1)[:show_max_n, -top_k:][:, ::]
    pred_1_labels = preds.argsort(axis=1)[:show_max_n, -top_k:][:, -1]
    if class_labels:
        pred_labels   = [[class_labels.get_name(value=l) for l in pred]
                         for pred in pred_labels]
        pred_1_labels = [class_labels.get_name(value=l) for l in pred_1_labels]
        targets 	  = [class_labels.get_name(value=l) for l in targets]
    
    # Prepare labels
    if labels is None:
        labels = [f"" for i in range(images_.shape[0])]
    labels = [f"{l} \n gt={gt}"
              for (l, pred, gt) in zip(labels, pred_1_labels, targets)]
    colors = ["darkgreen" if pred == gt else "red"
              for (pred, gt) in zip(pred_1_labels, targets)]
    if len(labels) != images_.shape[0]:
        raise ValueError(f"Length of `labels` and `images` batch size must be the same."
                         f" But got: {len(labels)} != {images_.shape[0]}.")
    
    # Create an image grid
    n, h, w, c = images_.shape
    ncols 	   = 8
    nrows	   = int(math.ceil(n / ncols))
    y_pos 	   = np.arange(top_k)
    fig = plt.figure(
        constrained_layout=True, num=figure_num,
        figsize=[(ncols * 1.0) * scale, (nrows * 1.5) * scale]
    )
    subfigs 	 = fig.subfigures(nrows=nrows, ncols=ncols)
    subfigs_flat = subfigs.flat
    move_figure(x=0, y=0)
    
    for idx, (img, label, color, scores, labels) in \
        enumerate(zip(images_, labels, colors, pred_scores, pred_labels)):
        subfig = subfigs_flat[idx]
        subfig.suptitle(label, x=0.5, y=1.0, color=color)
        axes = subfig.subplots(2, 1)
        for ax in axes.flat:
            ax.set_xticklabels([])
            ax.set_yticklabels([])
            ax.tick_params(axis="x", direction="in", pad=-10)
            ax.tick_params(axis="y", direction="in", pad=-10)
        # Image
        axes[0].imshow(img, aspect="auto")
        # Classlabels
        pps = axes[1].barh(y_pos, scores, align="center", color="deepskyblue")
        axes[1].set_xlim(left=0.0)
        axes[1].set_yticks(y_pos)
        axes[1].set_yticklabels(labels, horizontalalignment="left")
        # Scores
        max_width = max([rect.get_width() for rect in pps])
        for i, rect in enumerate(pps):
            if scores[i] > 0:
                axes[1].text(
                    rect.get_x() + max_width, rect.get_y(),
                    "{:.2f}".format(scores[i]), ha="right", va="bottom",
                    rotation=0
                )
    # plt.tight_layout()
    plt.subplots_adjust(wspace=0.0, hspace=0.0)
    
    # Save figure
    if save_cfg:
        filepath = save_cfg.pop("filepath")
        plt.savefig(filepath, **save_cfg)

    # Show
    if verbose:
        plt.show()
        plt.pause(wait_time)


# H1: - All --------------------------------------------------------------------

__all__ = [
    name for name, value in inspect.getmembers(
        sys.modules[__name__],
        predicate=lambda f: inspect.isfunction(f) and f.__module__ == __name__
    )
]
