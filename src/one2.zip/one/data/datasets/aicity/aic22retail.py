#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""A2I2-Haze Detection dataset and datamodule.
"""

from __future__ import annotations


# MARK: - Module
